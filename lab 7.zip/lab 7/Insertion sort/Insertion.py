def insertionSort(array):

    for n in range(1, len(array)):
        key = array[n]
        j = n - 1
      
        while j >= 0 and key < array[j]:
            array[j + 1] = array[j]
            j = j - 1

        array[j + 1] = key

data = [11,4,7,5,10,9,13,1]
insertionSort(data)
print('Sorted Array in Ascending Order:')
print(data)