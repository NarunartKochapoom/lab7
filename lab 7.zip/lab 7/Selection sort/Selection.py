def selection_sort(array1):  
    length = len(array1)  
      
    for i in range(length-1):  
        minIndex = i  
          
        for j in range(i+1, length):  
            if array1[j]<array1[minIndex]:  
                minIndex = j  
                  
        array1[i],array1[minIndex] = array1[minIndex],array1[i]  
          
    return array1      
array1 = [11,4,7,5,10,9,13,1]  
  
print(selection_sort(array1))