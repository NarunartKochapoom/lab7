def bubbleSort(array1):

  for i in range(len(array1)):

    for j in range(0, len(array1) - i - 1):

      if array1[j] > array1[j + 1]:

        temp = array1[j]
        array1[j] = array1[j+1]
        array1[j+1] = temp

data = [11,4,7,5,10,9,13,1]

bubbleSort(data)

print(data)